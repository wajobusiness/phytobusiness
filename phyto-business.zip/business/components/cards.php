<?php
/**
 * PhytoScience Wellness - Reusable Card Components
 * Modular rendering helpers for package tiers, leadership profiles, 4P pillars, and global offices.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';

/**
 * Render a Package Tier Card
 */
function render_package_card(array $pkg, bool $showDetailedCta = true): string
{
    $isFeatured = !empty($pkg['featured']);
    $featuredBadge = $isFeatured ? '<span class="ps-package-featured-badge">MOST POPULAR • MAXIMUM PAIRING</span>' : '';
    $cardClasses = 'ps-card ps-package-card ' . ($isFeatured ? 'featured' : '');

    $featuresHtml = '';
    foreach ($pkg['features'] as $feature) {
        $featuresHtml .= '
        <li class="d-flex align-items-start gap-2 mb-2">
            <svg class="text-crimson flex-shrink-0 mt-1" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
            <span class="small text-secondary">' . sanitize($feature) . '</span>
        </li>';
    }

    $rawUsd = (float)preg_replace('/[^0-9.]/', '', $pkg['price_usd'] ?? '130');
    $displayNgn = sanitize($pkg['price_ngn'] ?? $pkg['price_estimate']);
    $displayUsd = sanitize($pkg['price_usd'] ?? '$130');

    $ctaHtml = $showDetailedCta
        ? '<a href="' . get_business_url('join.php?package=' . urlencode($pkg['slug'])) . '" class="btn-ps ' . ($isFeatured ? 'btn-ps-primary' : 'btn-ps-outline-crimson') . ' w-100 mt-auto">Choose ' . sanitize($pkg['name']) . '</a>'
        : '<a href="' . get_business_url('membership.php') . '" class="btn-ps btn-ps-outline-crimson w-100 mt-auto">View Package Details</a>';

    return '
    <div class="' . $cardClasses . '">
        ' . $featuredBadge . '
        <div class="d-flex justify-content-between align-items-start mb-2">
            <div>
                <span class="badge bg-dark text-crimson border border-danger border-opacity-25 px-2 py-1 mb-2 font-monospace small">' . sanitize((string)$pkg['pp']) . ' PP</span>
                <h3 class="h4 text-white mb-0">' . sanitize($pkg['name']) . '</h3>
            </div>
            ' . ($isFeatured ? '<span class="badge bg-crimson fw-bold">Stockist Tier</span>' : '') . '
        </div>

        <p class="small text-secondary mb-3">' . sanitize($pkg['tagline']) . '</p>

        <div class="ps-package-pricing py-3 mb-3 border-top border-bottom border-secondary border-opacity-25">
            <div class="d-flex align-items-baseline gap-1 flex-wrap">
                <span class="small text-secondary">Est.</span>
                <span class="h2 text-white fw-bold mb-0" data-price-usd="' . $rawUsd . '">' . $displayNgn . '</span>
                <span class="small text-gold ms-2 fw-semibold">(' . $displayUsd . ' Int\'l)</span>
            </div>
            <div class="small text-crimson mt-1 fw-semibold">Daily Pairing Cap: ' . sanitize($pkg['daily_cap']) . '</div>
        </div>

        <div class="mb-4">
            <div class="text-white small fw-bold text-uppercase mb-2" style="letter-spacing: 0.05em; font-size: 0.75rem;">Included Benefits</div>
            <ul class="list-unstyled mb-0">
                ' . $featuresHtml . '
            </ul>
        </div>

        ' . $ctaHtml . '
    </div>';
}

/**
 * Render a Leadership or Scientist Card
 */
function render_person_card(array $person): string
{
    $name = sanitize($person['name'] ?? '');
    $title = sanitize($person['title'] ?? '');
    $credentials = sanitize($person['credentials'] ?? $person['specialty'] ?? $person['role'] ?? '');
    $bio = sanitize($person['bio'] ?? '');

    $imagePlaceholder = '
    <div class="d-flex align-items-center justify-content-center w-100 h-100 text-crimson fs-1 fw-bold" style="background: linear-gradient(135deg, #181920 0%, #2A1015 100%);">
        ' . (!empty($name) ? substr($name, 0, 1) : 'P') . '
    </div>';

    $credentialsBadge = !empty($credentials) 
        ? '<div class="badge bg-dark-subtle text-secondary border border-secondary border-opacity-25 px-2 py-1 mb-3 small">' . $credentials . '</div>' 
        : '';

    return '
    <div class="ps-card ps-team-card h-100 p-4">
        <div class="ps-avatar-wrapper mb-3 mx-auto" style="width: 130px; height: 130px; border-radius: 50%; overflow: hidden; border: 2px solid var(--ps-border-crimson); box-shadow: var(--ps-shadow-md);">
            ' . $imagePlaceholder . '
        </div>
        <div class="text-center">
            <h4 class="h5 text-white mb-1">' . $name . '</h4>
            <div class="small text-crimson fw-semibold mb-2">' . $title . '</div>
            ' . $credentialsBadge . '
            <p class="small text-secondary mb-0" style="line-height: 1.55;">' . $bio . '</p>
        </div>
    </div>';
}

/**
 * Render 4P Pillar Feature Card
 */
function render_4p_card(string $pillar, string $title, string $tagline, string $description, string $iconSvg, string $link = ''): string
{
    $linkBtn = !empty($link) 
        ? '<a href="' . $link . '" class="text-crimson small fw-semibold text-decoration-none d-inline-flex align-items-center gap-1 mt-3 hover-underline">Learn More <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>' 
        : '';

    return '
    <div class="ps-card h-100 p-4 position-relative">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <div class="ps-icon-box text-crimson p-3 rounded-circle" style="background: rgba(216, 0, 29, 0.12); border: 1px solid var(--ps-border-crimson);">
                ' . $iconSvg . '
            </div>
            <span class="badge bg-crimson fw-bold">' . sanitize($pillar) . '</span>
        </div>
        <h3 class="h5 text-white mb-1">' . sanitize($title) . '</h3>
        <div class="small text-crimson mb-2 fw-semibold">' . sanitize($tagline) . '</div>
        <p class="small text-secondary mb-0" style="line-height: 1.6;">' . sanitize($description) . '</p>
        ' . $linkBtn . '
    </div>';
}

/**
 * Render International Office Card
 */
function render_office_card(array $office): string
{
    $country = sanitize($office['country'] ?? '');
    $city = sanitize($office['city'] ?? '');
    $address = sanitize($office['address'] ?? '');
    $isHq = !empty($office['is_hq']) || stripos($country, 'HQ') !== false;

    $statusBadge = $isHq 
        ? '<span class="badge bg-crimson fw-bold">GLOBAL HQ</span>' 
        : '<span class="badge bg-dark text-light border border-secondary">Regional Hub</span>';

    $phoneLine = !empty($office['phone']) 
        ? '<div class="small text-secondary d-flex align-items-center gap-2 mb-1"><svg width="14" height="14" class="text-crimson" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg><span>' . sanitize($office['phone']) . '</span></div>' 
        : '';

    $emailLine = !empty($office['email']) 
        ? '<div class="small text-secondary d-flex align-items-center gap-2"><svg width="14" height="14" class="text-crimson" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg><span>' . sanitize($office['email']) . '</span></div>' 
        : '';

    return '
    <div class="ps-card h-100 p-4">
        <div class="d-flex justify-content-between align-items-start mb-2">
            <h4 class="h5 text-white mb-0">' . $country . '</h4>
            ' . $statusBadge . '
        </div>
        <div class="small text-crimson fw-semibold mb-3">' . $city . '</div>
        <p class="small text-secondary mb-3" style="line-height: 1.5;">' . $address . '</p>
        <div class="border-top border-secondary border-opacity-25 pt-2 mt-auto">
            ' . $phoneLine . '
            ' . $emailLine . '
        </div>
    </div>';
}
